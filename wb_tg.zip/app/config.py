# config.py
# Заполните значения перед запуском

# ---------- Telegram / авторизация ----------
API_ID = 32313129                #  API_ID
API_HASH = "ffff404fb0f747cfae2fa67059edaa9f"     #  API_HASH

# Если используете bot token:
USE_BOT_ACCOUNT = True
BOT_TOKEN = "8181110400:AAG1tQopNSsmgdBT0wuePQJlOIhtVTUe-Mk"  #BOT TOKEN если USE_BOT_ACCOUNT=True

# Если хотите использовать user-session (client без BOT_TOKEN), установите USE_BOT_ACCOUNT=False
SESSION_NAME = "price_reposter_session"

# ---------- Каналы ----------
# Можно указать список username или id (например: ["@source1", -1001234567890])
SOURCE_CHANNELS = ["@BigSaleApple"]
TARGET_CHANNEL = "@AppleSaleTest"

# ---------- Параметры изменения цен ----------
# Если в строке есть "PRO" (регистронезависимо) — вычитается PRICE_PRO_DELTA
# Иначе — PRICE_DEFAULT_DELTA
PRICE_PRO_DELTA = 2000.0
PRICE_DEFAULT_DELTA = 1000.0
# Если после вычета получилась отрицательная цена — поставить 0
MIN_PRICE_TO_ZERO = True

# ---------- Тайминги и скачивание ----------
REQUEST_DELAY = 0.45          # задержка между сетевыми вызовами
DOWNLOAD_DIR = "downloads"    # папка для временных файлов
DOWNLOAD_RETRIES = 3          # попыток загрузки медиа
ALBUM_BUFFER_DELAY = 1.0      # время ожидания элементов альбома (сек)

# ---------- Логирование ----------
LOG_DIR = "logs"
LOG_MAX_BYTES = 10 * 1024 * 1024  # 10 MB
LOG_BACKUP_COUNT = 5

# ---------- Админ-панель ----------
ADMIN_BIND_HOST = "127.0.0.1"
ADMIN_BIND_PORT = 8000
ADMIN_BASIC_USERNAME = "admin"
ADMIN_BASIC_PASSWORD = "changeme"  # смените

# ---------- Фильтрация сообщений ----------
# Обрабатывать ТОЛЬКО сообщения, начинающиеся с даты в формате:
# D/M/YYYY, DD/MM/YYYY, D.M.YYYY, D-M-YYYY и т.д.
DATE_START_REQUIRED = True

# Ключевые слова для распознавания информационных сообщений (игнорируются)
INFO_KEYWORDS = [
    "официальный аккаунт", "отдел продаж", "оптовая торговля",
    "гарантийный сервис", "ежедневно", "г. москва", "тц", "багратионовский",
    "контак", "📟", "+7", "телефон"
]

# ---------- Прочее ----------
# Максимальное количество сообщений, сохраняемых в БД в таблице recent_messages
RECENT_MESSAGES_LIMIT = 500
